<?php

namespace App\Http\Controllers\Admin;

use App\File;
use App\Folder;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Spatie\MediaLibrary\Media;
use Carbon\Carbon;

class DownloadsController extends Controller
{
    public function download($uuid) {
        if ( Auth::getUser()->id==null)
        {
            $user=2;
        }
        else
        {
            $user=Auth::getUser()->id==1;
        }
        $file = File::where([
            ['uuid', '=', $uuid]
         //   ['created_by_id', '=', $user]
            ])->first();
     //   dd($file);    
        $media = Media::where('model_id', $file->id)->first();
        $pathToFile = storage_path('app' . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . $file->id . DIRECTORY_SEPARATOR . $media->file_name );
            
        return  response()->file($pathToFile);
    }

    public function imprimir($id){
        $today = Carbon::now()->format('d/m/Y');
      $informepdf = Folder::where('id', $id)->first();
        $pdf = \PDF::loadView('admin/folders/informe', compact('informepdf','today'));
        return $pdf->download('informe.pdf');
   }
}
